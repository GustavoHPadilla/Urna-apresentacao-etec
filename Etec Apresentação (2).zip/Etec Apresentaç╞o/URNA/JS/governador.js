

window.addEventListener("keyup", function(event) {
    event.preventDefault();

    if(event.keyCode == 97){
        inserir(1)
    }if(event.keyCode == 98){
        inserir(2)
    }if(event.keyCode == 99){
        inserir(3)
    }if(event.keyCode == 100){
        inserir(4)
    }if(event.keyCode == 101){
        inserir(5)
    }if(event.keyCode == 102){
        inserir(6)
    }if(event.keyCode == 103){
        inserir(7)
    }if(event.keyCode == 104){
        inserir(8)
    }if(event.keyCode == 105){
        inserir(9)
    }if(event.keyCode == 96){
        inserir(0)
    }if(event.keyCode == 107){
        corrige()
    }if(event.keyCode == 109){
        branco()
    }
});

var a

function inserir(valor) {

    var c = 0
    var valor1 = document.getElementById("campo1").value;
    var valor2 = document.getElementById("campo2").value;

    if(document.getElementById("campo1").value == ""){
        document.getElementById("campo1").style.animation = "inpute 1s ease forwards infinite"
        document.getElementById("campo2").style.animation = "input 1s ease forwards infinite"

        a = 2

        document.getElementById("campo1").value = valor;
    }
    else if(document.getElementById("campo2").value == "") {
        document.getElementById("campo2").style.animation = "inpute 1s ease forwards infinite"
        
        document.getElementById("campo2").value = valor;
    } 
    else if(document.getElementById("campo2").value != ""){
        document.getElementById("campo2").style.animation = ""
    }

    var candidato = document.getElementById("campo1").value + document.getElementById("campo2").value;

    if(candidato == "13"){
        c++
        document.querySelector('.h1Info').style.display = 'none'
        document.querySelector('.imgCandidato').src = "IMG/CANDIDATOS/adriano.jpg"
        document.querySelector('.infoCandidato').style.display = "block"
        document.querySelector('.nomeH2').innerHTML = "Nome: Adriano Castro"
        document.querySelector('.partH2').innerHTML = "Partido: <b>Bootstrap</b>"
        document.querySelector('.viceH2').innerHTML = "Vice: Diego"
        window.addEventListener("keyup", function(event) {
            event.preventDefault();
            if(event.keyCode == 13){
                c == 1 ? votar() : null
                c = 2
            }
        })
    }
    else if(candidato == "22"){
        c++ 
        document.querySelector('.h1Info').style.display = 'none'
        document.querySelector('.imgCandidato').src = "IMG/CANDIDATOS/honorato.jpg"
        document.querySelector('.infoCandidato').style.display = "block"
        document.querySelector('.nomeH2').innerHTML = "Nome: Ricardo Honorato"
        document.querySelector('.partH2').innerHTML = "Partido: <b>PHP</b>"
        document.querySelector('.viceH2').innerHTML = "Vice: Alciano"
        window.addEventListener("keyup", function(event) {
            event.preventDefault();
            if(event.keyCode == 13){
                c == 1 ? votar() : null
                c = 2
            }
        })
    }
    else if(candidato == "17"){
        c++
        document.querySelector('.h1Info').style.display = 'none'
        document.querySelector('.imgCandidato').src = "IMG/CANDIDATOS/fernando.jpg"
        document.querySelector('.infoCandidato').style.display = "block"
        document.querySelector('.nomeH2').innerHTML = "Nome: Fernando Silva"
        document.querySelector('.partH2').innerHTML = "Partido: <b>Java</b>"
        document.querySelector('.viceH2').innerHTML = "Vice: Lucas"
        window.addEventListener("keyup", function(event) {
            event.preventDefault();
            if(event.keyCode == 13){
                c == 1 ? votar() : null
                c = 2
            }
        })
    }

}

function corrige() {
    document.querySelector('.imgCandidato').src = ""
    document.querySelector('.infoCandidato').style.display = "none"

    document.getElementById("campo1").value = "";
    document.getElementById("campo2").value = "";

    document.querySelector('.h1Info').style.display = 'none'
    document.getElementById("campo1").style.animation = "input 1s ease forwards infinite"

    if(a == 2){
        document.getElementById("campo2").style.animation = "inpute 1s ease forwards infinite"
        a = 0
    }

    document.querySelector('.libra').src = "IMG/LIBRA/presidente.gif"
}


function branco(){
    c++
    document.querySelector('.h1Info').style.display = 'block'
    document.querySelector('.h1Info').innerHTML = "VOTO EM BRANCO"
    window.addEventListener("keyup", function(event) {
        event.preventDefault();
        if(event.keyCode == 13){
            c == 1 ? votar() : null
            c = 2
        }
    })
}


function votar() {
    document.querySelector('.confirmaAudio').play()

    document.querySelector('.governador').style.display = 'none'
    document.querySelector('.final').style.display = 'flex'
    
    setTimeout(() => {
        document.querySelector('.final').style.display = 'none'
        document.querySelector('.fim').style.display = 'flex'
        document.querySelector('.fimAudio').play()
    }, 1200)
}




const timeElapsed = Date.now();
const today = new Date(timeElapsed);

document.querySelector('.datahora').innerHTML = today.toUTCString();